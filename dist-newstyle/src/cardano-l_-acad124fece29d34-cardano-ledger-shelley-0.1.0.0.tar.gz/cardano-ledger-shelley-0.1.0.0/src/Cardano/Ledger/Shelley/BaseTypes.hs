module Cardano.Ledger.Shelley.BaseTypes
  {-# DEPRECATED "Use 'import Cardano.Ledger.BaseTypes' instead." #-}
  (module X)
where

import Cardano.Ledger.BaseTypes as X
