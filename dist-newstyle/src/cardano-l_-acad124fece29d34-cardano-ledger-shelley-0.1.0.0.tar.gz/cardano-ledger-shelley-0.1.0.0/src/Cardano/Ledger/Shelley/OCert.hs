module Cardano.Ledger.Shelley.OCert
  {-# DEPRECATED "Use 'import Cardano.Protocol.TPraos.OCert' instead." #-}
  (module X)
where

import Cardano.Protocol.TPraos.OCert as X
