module Cardano.Ledger.Shelley.Address
  {-# DEPRECATED "Use 'import Cardano.Ledger.Address' instead." #-}
  (module X)
where

import Cardano.Ledger.Address as X
