module Cardano.Ledger.Shelley.Rules.Overlay
  {-# DEPRECATED "Use 'import Cardano.Protocol.TPraos.Rules.Overlay' instead." #-}
  (module X)
where

import Cardano.Protocol.TPraos.Rules.Overlay as X
