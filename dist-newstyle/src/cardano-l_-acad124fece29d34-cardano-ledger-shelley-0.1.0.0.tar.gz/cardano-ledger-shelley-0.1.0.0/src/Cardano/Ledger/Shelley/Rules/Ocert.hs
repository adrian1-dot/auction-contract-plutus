module Cardano.Ledger.Shelley.Rules.Ocert
  {-# DEPRECATED "Use 'import Cardano.Protocol.TPraos.Rules.OCert' instead." #-}
  (module X)
where

import Cardano.Protocol.TPraos.Rules.OCert as X
