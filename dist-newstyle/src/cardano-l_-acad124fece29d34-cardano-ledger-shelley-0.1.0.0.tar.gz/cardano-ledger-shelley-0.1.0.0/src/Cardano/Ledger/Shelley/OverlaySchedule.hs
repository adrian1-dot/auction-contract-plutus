{-# LANGUAGE DataKinds #-}
{-# LANGUAGE DeriveGeneric #-}
{-# LANGUAGE DerivingStrategies #-}
{-# LANGUAGE LambdaCase #-}

module Cardano.Ledger.Shelley.OverlaySchedule
  {-# DEPRECATED "Use 'import Cardano.Protocol.TPraos.Rules.Overlay' instead." #-}
  (module X)
where

import Cardano.Protocol.TPraos.Rules.Overlay as X
