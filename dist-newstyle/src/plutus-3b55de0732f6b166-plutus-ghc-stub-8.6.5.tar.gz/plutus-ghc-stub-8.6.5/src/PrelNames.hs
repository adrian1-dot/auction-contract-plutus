module PrelNames where

import           StubTypes

eqIntegerPrimName, eqName :: Name
isStringClassName :: Name
eqIntegerPrimName = error "eqInteger#"
eqName = error "eqName"
isStringClassName = error "isStringClassName"
