module TcRnTypes (TcPlugin) where

data TcPlugin = TcPlugin
