module Cardano.Protocol.TPraos
  {-# DEPRECATED "Use 'import Cardano.Ledger.BaseTypes' instead." #-}
  (IndividualPoolStake (..), PoolDistr (..), ProtVer (..))
where

import Cardano.Ledger.BaseTypes (ProtVer (..))
import Cardano.Ledger.PoolDistr (IndividualPoolStake (..), PoolDistr (..))
